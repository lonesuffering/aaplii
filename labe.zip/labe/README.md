# Lab E TypeScript - Полный код

Я создал полный проект согласно требованиям лабораторной работы. Вот структура файлов:

## Структура проекта

```
lab-e/
├── index.html          # Основная HTML страница
├── package.json        # NPM конфигурация
├── tsconfig.json       # TypeScript конфигурация
├── src/
│   └── script.ts       # TypeScript скрипт
└── public/styles/
    ├── style1.css      # Clean Minimal
    ├── style2.css      # Dark Mode
    ├── style3.css      # Warm Earth
    └── style4.css      # Modern Gradient
```

## Инструкция по запуску

1. **Создайте папку проекта:**
   ```bash
   mkdir lab-e
   cd lab-e
   ```

2. **Скопируйте файлы:**
   - `index.html` - в корень папки
   - `package.json` - в корень папки
   - `tsconfig.json` - в корень папки
   - `script.ts` - в папку `src/`
   - `style1.css`, `style2.css`, `style3.css`, `style4.css` - в папку `public/styles/`

3. **Установите зависимости:**
   ```bash
   npm install
   ```

4. **Запустите dev сервер:**
   ```bash
   npm run dev
   ```

5. **Откройте в браузере:**
   Обычно это `http://localhost:5173/`

## Что делает приложение

✅ **Динамическая смена стилей CSS** - клик на "Switch to style1/2/3/4" меняет подключенный CSS файл через `<link id="dynamic-style">`

✅ **TypeScript функции:**
- `loadStyle(styleName: string): void` - меняет href у ссылки #dynamic-style
- `createLinks(): void` - динамически создает ссылки из массива styles

✅ **Четыре разных стиля:**
1. **style1.css** - Clean Minimal (белый фон, синие кнопки)
2. **style2.css** - Dark Mode (черный фон, cyan кнопки с бордером)
3. **style3.css** - Warm Earth (бежевый фон, serif шрифт, коричневые кнопки)
4. **style4.css** - Modern Gradient (градиент фиолетовый, золотые кнопки с анимацией)

## Файлы готовы к скачиванию

Все файлы сформированы выше. Просто скопируйте их в соответствующие папки проекта и запустите `npm install && npm run dev`.

Приложение полностью соответствует требованиям из LAB E! 🚀