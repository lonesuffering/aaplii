type StyleName = string;

type AppState = {
  currentStyle: StyleName;
};

const styles: Record<StyleName, string> = {
  style1: "/styles/style1.css",
  style2: "/styles/style2.css",
  style3: "/styles/style3.css",
  // Если нужно 4-й стиль для скрина — просто раскомментируй:
  // style4: "/styles/style4.css",
};

const state: AppState = {
  currentStyle: "style1",
};

function loadStyle(styleName: StyleName): void {
  const href = styles[styleName];
  if (!href) return;

  const existingLink = document.getElementById("dynamic-style") as HTMLLinkElement | null;

  // Требование: “z DOM usunięte zostaje odwołanie do starego stylu CSS, a dodane zostaje ...” [file:3]
  // Реализуем безопасно: если link есть — меняем href; если нет — создаём новый.
  if (existingLink) {
    existingLink.href = href;
  } else {
    const link = document.createElement("link");
    link.id = "dynamic-style";
    link.rel = "stylesheet";
    link.href = href;
    document.head.appendChild(link);
  }

  state.currentStyle = styleName;
}

function createLinks(): void {
  const container = document.getElementById("style-links") as HTMLDivElement | null;
  if (!container) return;

  container.innerHTML = ""; // очистка

  Object.keys(styles).forEach((styleName) => {
    if (styleName === state.currentStyle) return; // “linki do stron w innych stylach” [file:3]

    const link = document.createElement("a");
    link.href = "#";
    link.textContent = `Switch to ${styleName}`;
    link.style.marginRight = "10px";

    link.addEventListener("click", (e: MouseEvent) => {
      e.preventDefault();
      loadStyle(styleName);
      createLinks(); // чтобы после смены снова показать "другие" стили
    });

    container.appendChild(link);
  });
}

// init
createLinks();
